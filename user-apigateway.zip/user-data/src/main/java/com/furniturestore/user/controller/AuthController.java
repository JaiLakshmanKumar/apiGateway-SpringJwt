package com.furniturestore.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.furniturestore.user.Exception.UserExistException;
import com.furniturestore.user.dto.AuthRequest;
import com.furniturestore.user.entity.UserData;
import com.furniturestore.user.service.JwtService;
import com.furniturestore.user.service.AuthService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth") // authservice
public class AuthController {
	@Autowired
	private AuthService authService;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/register")
	public UserData addUser(@Valid @RequestBody UserData user) throws UserExistException {
		System.out.println("hello");
		return authService.addUser(user);
	}

	@PostMapping("/login")//generates jwt token here after login
	public String loginUser(@RequestBody AuthRequest authRequest) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		if (authentication.isAuthenticated()) {
			return authService.generateToken(authRequest.getUsername());
		} else {
			throw new UsernameNotFoundException("Invalid User");
		}

	}

	@GetMapping("/validate")
	public String validateToken(@RequestParam("token") String token) {
		authService.validateToken(token);
        return "Token is valid";
    }
}
