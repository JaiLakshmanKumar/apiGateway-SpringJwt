package com.furniturestore.user.Exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestController
public class GlobalExceptionAdvicer {
	
	@ExceptionHandler(UserExistException.class)
	public ResponseEntity<ErrorResponse> userNotFound(UserExistException ex){
		ErrorResponse errorResponse=new ErrorResponse();
		errorResponse.setErrorMessage(ex.getMessage());
		errorResponse.setErrorCode(HttpStatus.NOT_ACCEPTABLE.value());
		errorResponse.setErrorTime(LocalDateTime.now());
		return new ResponseEntity<>(errorResponse,HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ErrorResponse> userNotFound(MethodArgumentTypeMismatchException ex){
		ErrorResponse errorResponse=new ErrorResponse();
		errorResponse.setErrorMessage(ex.getMessage());
		errorResponse.setErrorCode(HttpStatus.BAD_REQUEST.value());
		errorResponse.setErrorTime(LocalDateTime.now());
		return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> userNotFound(Exception ex){
		ErrorResponse errorResponse=new ErrorResponse();
		errorResponse.setErrorMessage(ex.getMessage());
		errorResponse.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errorResponse.setErrorTime(LocalDateTime.now());
		return new ResponseEntity<>(errorResponse,HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
