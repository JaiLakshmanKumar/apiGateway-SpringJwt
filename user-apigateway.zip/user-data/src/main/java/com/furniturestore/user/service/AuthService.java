package com.furniturestore.user.service;

import org.springframework.stereotype.Service;

import com.furniturestore.user.Exception.UserExistException;

import com.furniturestore.user.entity.UserData;

@Service
public interface AuthService {
	public UserData addUser(UserData user)throws UserExistException;
	public String generateToken(String username);
	public void validateToken(String token);
}
