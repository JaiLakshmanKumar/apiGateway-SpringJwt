package com.furniturestore.user.config;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.furniturestore.user.entity.UserData;


public class CustomeUserDetails implements UserDetails {

    private String userName;
    private String password;
    

    

    public CustomeUserDetails(UserData userData) {
		super();
		this.userName = userData.getUserName();
		this.password = userData.getPassword();
	}

	@Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return userName;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true; // You can customize based on your needs
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // You can customize based on your needs
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // You can customize based on your needs
    }

    @Override
    public boolean isEnabled() {
        return true; // You can customize based on your needs
    }
}
