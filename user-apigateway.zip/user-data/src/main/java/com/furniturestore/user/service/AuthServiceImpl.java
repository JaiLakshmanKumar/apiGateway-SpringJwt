package com.furniturestore.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.furniturestore.user.Exception.UserExistException;
import com.furniturestore.user.entity.UserData;
import com.furniturestore.user.repository.UserDataRepository;

@Service
public class AuthServiceImpl implements AuthService{
	@Autowired
	private UserDataRepository userDataRepository;
	
	
	@Autowired
	private JwtService jwtService;
	
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	boolean flag ;
	@Override
	public UserData addUser(UserData user) throws UserExistException {
		Optional<UserData> users=userDataRepository.findByUserName(user.getUserName());
		if(users.isEmpty()) {
			user.setPassword(passwordEncoder.encode( user.getPassword()));
			return userDataRepository.save(user);
			 
		}else {
			throw new UserExistException("User is already there.");
		}
	        
			
	
	}
	
	@Override
	public String generateToken(String username){
		return jwtService.generateToken(username);
		
	}

	@Override
	public void validateToken(String token) {
		
		jwtService.validateToken(token);
		
	}
	
}
