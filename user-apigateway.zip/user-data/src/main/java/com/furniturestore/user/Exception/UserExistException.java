package com.furniturestore.user.Exception;

public class UserExistException extends Exception{

	public UserExistException(String msg) {
		super(msg);
	}

}
