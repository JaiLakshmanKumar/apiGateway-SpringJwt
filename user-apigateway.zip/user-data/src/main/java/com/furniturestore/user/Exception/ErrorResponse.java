package com.furniturestore.user.Exception;

import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {
	 
		private String errorMessage;
		private int errorCode;
		private LocalDateTime errorTime;
}
